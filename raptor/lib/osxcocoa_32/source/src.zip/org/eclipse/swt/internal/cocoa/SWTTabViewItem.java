package org.eclipse.swt.internal.cocoa;

public class SWTTabViewItem extends NSTabViewItem {

}
